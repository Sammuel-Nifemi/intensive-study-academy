export const academicStructure = {
  Science: [
    "Computer Science",
    "Biology",
    "Physics",
    "Chemistry"
  ],
  Arts: [
    "English",
    "History",
    "Philosophy"
  ],
  Management: [
    "Accounting",
    "Business Administration"
  ]
};
