export let usageData = [
  {
    studentId: "NOU233396887",

    summaries: {
      count: 0,
      freeLimit: 3
    },

    pastQuestions: {
      count: 0,
      freeLimit: 3
    },

    mocks: {
      count: 0,
      freeLimit: 3
    },

    mockPdfDownloads: {
      count: 0,
      freeLimit: 0 // always paid
    }
  }
];
